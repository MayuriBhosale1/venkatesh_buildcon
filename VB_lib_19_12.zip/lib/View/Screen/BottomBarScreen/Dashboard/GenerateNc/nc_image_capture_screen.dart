// nc_image_capture_screen.dart

import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_painter/image_painter.dart';
import 'package:path_provider/path_provider.dart';

class NcImageCaptureWidget extends StatefulWidget {
  final List<File> initialImages; // Existing images (if any)
  final Function(List<File>) onImagesUpdated; // Callback to parent screen
  final String title;

  const NcImageCaptureWidget({
    super.key,
    required this.initialImages,
    required this.onImagesUpdated,
    required this.title,
  });

  @override
  _NcImageCaptureWidgetState createState() => _NcImageCaptureWidgetState();
}

class _NcImageCaptureWidgetState extends State<NcImageCaptureWidget> {
  final ImagePicker _picker = ImagePicker();
  List<File> _images = [];

  @override
  void initState() {
    super.initState();
    _images = List<File>.from(widget.initialImages);
  }

  //   Pick Image with Pen Editor
  Future<void> _pickImage(ImageSource source) async {
    if (_images.length >= 5) {
      _showSnackbar(
          "You've reacched the limit - you can add up to 5 photos only.");
      return;
    }

    final XFile? picked = await _picker.pickImage(source: source);
    if (picked == null) return;

    File original = File(picked.path);
    File? edited = await _openPenRemarkEditor(original);

    if (edited != null) {
      setState(() {
        _images.add(edited);
      });
      widget.onImagesUpdated(_images);
    }
  }

  // Pen Remark Drawing Screen
  Future<File?> _openPenRemarkEditor(File imageFile) async {
    final GlobalKey<ImagePainterState> painterKey =
        GlobalKey<ImagePainterState>();

    return await showDialog<File?>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return Dialog(
          insetPadding: const EdgeInsets.all(10),
          backgroundColor: Colors.white,
          child: Column(
            children: [
              // HEADER
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    TextButton(
                      onPressed: () =>
                          // Navigator.pop(dialogContext),
                          //12/12
                          Navigator.of(dialogContext, rootNavigator: true)
                              .pop(),
                      child: const Text("Cancel",
                          style: TextStyle(color: Colors.red)),
                    ),
                    const Text(
                      "Pen Remark",
                      style:
                          TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    TextButton(
                      onPressed: () async {
                        try {
                          final imgBytes =
                              await painterKey.currentState?.exportImage();
                          if (imgBytes != null) {
                            final dir =
                                await getApplicationDocumentsDirectory();
                            final path =
                                '${dir.path}/pen_edit_${DateTime.now().millisecondsSinceEpoch}.png';

                            final File edited = File(path);
                            await edited.writeAsBytes(imgBytes);

                            // Navigator.pop(dialogContext, edited);
                            //12/12
                            Navigator.of(dialogContext, rootNavigator: true)
                                .pop(edited);
                          } else {
                            Navigator.pop(dialogContext, imageFile);
                          }
                        } catch (e) {
                          Navigator.pop(dialogContext, imageFile);
                        }
                      },
                      child: const Text("Save",
                          style: TextStyle(color: Colors.blue)),
                    ),
                  ],
                ),
              ),

              // IMAGE PAINTER
              Expanded(
                child: ImagePainter.file(
                  imageFile,
                  key: painterKey,
                  scalable: true,
                  initialStrokeWidth: 2,
                  initialPaintMode: PaintMode.freeStyle,
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // Full Screen Image Viewer
  void _viewImage(File file) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: Stack(
          children: [
            InteractiveViewer(
              child: Center(child: Image.file(file, fit: BoxFit.contain)),
            ),
            Positioned(
              top: 40,
              right: 20,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 30),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  //  Image Picker UI
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // const Text(
        //   "Rectified Images",
        //   style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        // ),
        Text(
          widget.title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),

        const SizedBox(height: 10),

        // SHOW SELECTED IMAGES
        if (_images.isNotEmpty)
          SizedBox(
            height: 160,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _images.length,
              itemBuilder: (context, index) {
                final img = _images[index];
                return Stack(
                  children: [
                    GestureDetector(
                      onTap: () => _viewImage(img),
                      child: Container(
                        width: 140,
                        margin: const EdgeInsets.only(right: 10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          image: DecorationImage(
                            image: FileImage(img),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),

                    // DELETE BUTTON
                    Positioned(
                      right: 5,
                      top: 5,
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _images.removeAt(index);
                          });
                          widget.onImagesUpdated(_images);
                        },
                        child: const CircleAvatar(
                          radius: 14,
                          backgroundColor: Colors.redAccent,
                          child:
                              Icon(Icons.close, color: Colors.white, size: 16),
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),

        const SizedBox(height: 10),

        // BUTTONS
        Row(
          children: [
            ElevatedButton.icon(
              onPressed: () => _pickImage(ImageSource.camera),
              icon: const Icon(Icons.camera_alt),
              label: const Text("Capture"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.black54),
            ),
            const SizedBox(width: 12),
            ElevatedButton.icon(
              onPressed: () => _pickImage(ImageSource.gallery),
              icon: const Icon(Icons.photo),
              label: const Text("Gallery"),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.black54),
            ),
          ],
        ),
      ],
    );
  }

  void _showSnackbar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        duration: const Duration(seconds: 2),
      ),
    );
  }
  //
  //16/12
// Widget _imageBox(String fullUrl) {
//   return GestureDetector(
//     onTap: () {
//       showDialog(
//         context: context,
//         builder: (_) => Dialog(
//           insetPadding: EdgeInsets.zero,
//           backgroundColor: Colors.black,
//           child: Stack(
//             children: [
//               InteractiveViewer(
//                 child: Center(
//                   child: Image.network(
//                     fullUrl,
//                     fit: BoxFit.contain,
//                     loadingBuilder: (context, child, progress) {
//                       if (progress == null) return child;
//                       return const Center(
//                         child: CircularProgressIndicator(color: Colors.white),
//                       );
//                     },
//                     errorBuilder: (_, __, ___) => const Center(
//                       child: Icon(Icons.broken_image,
//                           color: Colors.white, size: 60),
//                     ),
//                   ),
//                 ),
//               ),
//               Positioned(
//                 top: 40,
//                 right: 20,
//                 child: IconButton(
//                   icon: const Icon(Icons.close,
//                       color: Colors.white, size: 30),
//                   onPressed: () => Navigator.pop(context),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       );
//     },
//     child: ClipRRect(
//       borderRadius: BorderRadius.circular(8.0),
//       child: Image.network(
//         fullUrl,
//         height: 120,
//         width: 120,
//         fit: BoxFit.cover,
//         errorBuilder: (_, __, ___) => Container(
//           height: 120,
//           width: 120,
//           color: Colors.grey[300],
//           child: const Icon(Icons.broken_image, color: Colors.grey),
//         ),
//       ),
//     ),
//   );
// }
}
